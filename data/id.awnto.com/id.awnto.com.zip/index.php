<!--

You can use your own index page here
this is sample index page with login.php included.

-->

<?php
include 'login.php'
?>