<?php
	require_once("application/session.php");
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
		
		
	<title>Awnto ID - Home</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="http://hub.awnto.com/data/id.awnto.com/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="http://hub.awnto.com/data/id.awnto.com/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="http://hub.awnto.com/data/id.awnto.com/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="http://hub.awnto.com/data/id.awnto.com/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
	
	
	</head>
<body>
	
	
<span class="login100-form-title">
	<br><br>
						Awnto ID
						<br><br>
						
						<img width="80%" src="http://hub.awnto.com/data/id.awnto.com/images/awnto_id.png" alt="awnto_id">
					
					</span>

<div class="signin-form">
<div class="container">

	<div >
		
		
			<a class="login100-form-btn" href="http://awnto.com">Awnto Home</a>
			
			<br>
			<a class="login100-form-btn" href="home.php">Home</a>
			
			<br>
			<a class="login100-form-btn" href="changepass.php">Change Password</a>
			
 &nbsp;
			<a class="login100-form-btn" href="application/logout.php?logout=true" >Logout</a>
		</nav><br><br><br>
	</div>

<!-- You need this element to prevent the content of the page from jumping up -->
<div class="header-fixed-placeholder"></div>
<!-- The content of your page would go here. -->

<div class="menu">
	<h1></h1>
</div>
<div>
	<h2 style="margin-left:150px; margin-top:40px"></h2>
</center>

<!-- Your scripts. -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<!-- Your scripts. -->
</body>

</html>
